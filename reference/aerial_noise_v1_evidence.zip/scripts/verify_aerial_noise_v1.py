"""Check displayed coordinates, labels and attributes against original LAS records."""
import sys, json, hashlib, base64, ctypes, zipfile
from pathlib import Path
ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(),255)
sys.path[:0]=['E:/NeuralMap/runtime/aerial-libs','E:/NeuralMap/runtime/scene-v2-libs']
import numpy as np
import laspy
R=Path('E:/NeuralMap');E=R/'stage0/evidence/aerial_noise_v1'
files=json.loads((E/'downloads.json').read_text())['files']
analysis=json.loads((E/'analysis.json').read_text());maxerr=0.;views=0
with zipfile.ZipFile(R/'runtime/tmp/aerial_noise_v1_raw.zip') as z:
    for f in files:
        assert hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['sha256']
        assert hashlib.sha256(z.read(f['key'])).hexdigest()==f['sha256']
        a=laspy.read(f['path'],laz_backend=laspy.LazBackend.Lazrs)
        xyz=np.column_stack((a.x,a.y,a.z));cls=np.asarray(a.classification)
        row=next(r for r in analysis['rows'] if r['id']==f['id'])
        assert len(a.points)==row['points'] and int(np.sum(cls==7))==row['noise_points']
        payload=json.loads((R/'stage0/assets/aerial_noise_v1'/(f['id']+'.json')).read_text())
        for i,v in enumerate(payload['views'],1):
            with np.load(R/'datasets/converted/aerial_noise_v1'/(f['id']+'_'+str(i)+'.npz')) as b:
                ix=b['source_indices'];assert len(ix)==len(np.unique(ix))
                err=np.max(np.abs(b['xyz_local'].astype('f8')+b['origin']-xyz[ix]),initial=0);maxerr=max(maxerr,float(err));assert err<.002
                for key in ['classification','intensity','return_number','number_of_returns','synthetic','key_point','withheld']:
                    assert np.array_equal(b[key],np.asarray(getattr(a,key))[ix])
                vp=np.frombuffer(base64.b64decode(v['xyz']),dtype='<f4').reshape(-1,3)
                vc=np.frombuffer(base64.b64decode(v['classes']),dtype='u1')
                assert np.array_equal(vp,b['xyz_local']) and np.array_equal(vc,b['classification'])
                assert len(ix)==v['n'] and int(np.sum(vc==7))==v['noise']
                if i==1:assert v['noise']==row['noise_points']
                views+=1
result=dict(source_files_verified=len(files),raw_zip_original_hashes_match=True,original_label_and_attribute_identity=True,views_verified=views,max_coordinate_roundtrip_error_m=maxerr,display_noise_counts_preserved=True,duplicates_added=False,training=False,heldout_opened=False)
(E/'numeric_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
