"""Build local and self-contained measured aerial noise review pages."""
from pathlib import Path
import json, shutil, zipfile
R=Path('E:/NeuralMap'); S=R/'stage0'; E=S/'evidence/aerial_noise_v1'
analysis=(E/'analysis.json').read_text(encoding='utf-8')
registry=(R/'configs/aerial_noise_sources_v1.json').read_text(encoding='utf-8')
template=(R/'scripts/aerial_noise_review_v1_template.html').read_text(encoding='utf-8')
js=(R/'scripts/aerial_noise_review_v1.js').read_text(encoding='utf-8')
three=(S/'assets/three-0.160.1.min.js').read_text(encoding='utf-8')
html=template.replace('__ANALYSIS__',analysis).replace('__REGISTRY__',registry).replace('__THREE__',three).replace('__SCRIPT__',js)
(S/'aerial_noise_review_v1.html').write_text(html.replace('__EMBEDDED__','{}'),encoding='utf-8')
embedded={p.stem:json.loads(p.read_text()) for p in (S/'assets/aerial_noise_v1').glob('*.json')}
P=R/'runtime/tmp/aerial_noise_publish_v1';P.mkdir(parents=True,exist_ok=True)
(P/'aerial_noise_review_v1.html').write_text(html.replace('__EMBEDDED__',json.dumps(embedded,separators=(',',':'))),encoding='utf-8')
shutil.copyfile(P/'aerial_noise_review_v1.html',S/'aerial_noise_review_v1_portable.html')
shutil.copyfile(R/'configs/aerial_noise_sources_v1.json',S/'aerial_noise_sources_v1.json')
downloads=json.loads((E/'downloads.json').read_text())
raw=R/'runtime/tmp/aerial_noise_v1_raw.zip'
if not raw.exists():
    with zipfile.ZipFile(raw,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
        for f in downloads['files']:z.write(f['path'],f['key'])
        for n in ['downloads.json','reservation.json']:z.write(E/n,n)
        z.write(S/'aerial_noise_sources_v1.json','sources_and_attribution.json')
with zipfile.ZipFile(S/'aerial_noise_v1_evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as z:
    for p in E.glob('*.json'):z.write(p,'evidence/aerial_noise_v1/'+p.name)
    for n in ['acquire_aerial_noise_v1.py','analyze_aerial_noise_v1.py','verify_aerial_noise_v1.py','publish_aerial_noise_v1.py','aerial_noise_review_v1.js','aerial_noise_review_v1_template.html']:z.write(R/'scripts'/n,'scripts/'+n)
    z.write(S/'aerial_noise_sources_v1.json','sources_and_attribution.json')
    z.write(S/'assets/three-LICENSE.txt','three-LICENSE.txt')
print('Published', (P/'aerial_noise_review_v1.html').stat().st_size,'portable bytes; raw zip',raw.stat().st_size)
