"""Describe reserved aerial calibration tiles; keep LAS classifications unchanged."""
import os, sys, ctypes, json, hashlib, base64
from pathlib import Path
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[name] = '8'
ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.windll.kernel32.GetCurrentProcess(), 255)
sys.path[:0] = ['E:/NeuralMap/runtime/aerial-libs','E:/NeuralMap/runtime/scene-v2-libs']
import numpy as np
import laspy
from scipy.spatial import cKDTree

R=Path('E:/NeuralMap'); E=R/'stage0/evidence/aerial_noise_v1'
C=R/'datasets/converted/aerial_noise_v1'; C.mkdir(parents=True,exist_ok=True)
A=R/'stage0/assets/aerial_noise_v1'; A.mkdir(parents=True,exist_ok=True)
files=json.loads((E/'downloads.json').read_text())['files']
reservation=json.loads((E/'reservation.json').read_text())
assert [f['key'] for f in files]==[f['key'] for f in reservation['selected']]

def q(a):
    return np.quantile(a,[.1,.5,.9]).tolist() if len(a) else None

def b64(a):
    return base64.b64encode(a.tobytes()).decode()

rows=[]
for fi, f in enumerate(files):
    p=Path(f['path']); assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256']
    las=laspy.read(p, laz_backend=laspy.LazBackend.Lazrs)
    xyz=np.column_stack((las.x,las.y,las.z)); cls=np.asarray(las.classification).copy()
    intensity=np.asarray(las.intensity).copy(); ret=np.asarray(las.return_number).copy(); totalret=np.asarray(las.number_of_returns).copy()
    assert len(xyz)==las.header.point_count and np.isfinite(xyz).all()
    noise=np.flatnonzero(cls==7); other=np.flatnonzero(cls!=7); ground=np.flatnonzero(cls==2)
    rng=np.random.default_rng(75100+fi)
    row={k:f[k] for k in ['id','dataset','key','url','sha256','bytes','split']}
    labels,counts=np.unique(cls,return_counts=True)
    row.update(points=len(xyz),noise_points=len(noise),noise_fraction=len(noise)/len(xyz),classes={str(int(k)):int(v) for k,v in zip(labels,counts)},bounds=[xyz.min(0).tolist(),xyz.max(0).tolist()],las_version=str(las.header.version),point_format=las.header.point_format.id,dimensions=list(las.point_format.dimension_names),noise_intensity_q10_50_90=q(intensity[noise]),other_intensity_q10_50_90=q(intensity[other]),noise_return_numbers={str(int(k)):int(v) for k,v in zip(*np.unique(ret[noise],return_counts=True))})
    if len(noise) and len(ground):
        tree=cKDTree(xyz[ground,:2]); dist,near=tree.query(xyz[noise,:2],workers=8)
        dz=xyz[noise,2]-xyz[ground[near],2]; valid=dist<=2
        row.update(ground_reference='Nearest class-2 point in XY within 2 m. Local-height proxy, not a reconstructed clean surface.',noise_ground_xy_q10_50_90=q(dist),noise_with_ground_within_2m=int(valid.sum()),noise_dz_near_ground_q10_50_90=q(dz[valid]),noise_below_ground_fraction_valid=float(np.mean(dz[valid]<0)) if valid.any() else None)
        del tree
    tree=cKDTree(xyz)
    for name,indices in [('noise',noise),('other',other)]:
        ix=rng.choice(indices,min(1024,len(indices)),replace=False)
        distances=tree.query(xyz[ix],k=9,workers=8)[0] if len(ix) else np.empty((0,9))
        row[name+'_mean8nn_q10_50_90']=q(distances[:,1:].mean(1))
    del tree
    origin=(xyz.min(0)+xyz.max(0))/2
    views=[]
    def make_view(name,indices,center=None):
        arr=(xyz[indices]-origin).astype('<f4')
        assert np.max(np.abs(arr.astype('f8')+origin-xyz[indices]),initial=0)<.002
        views.append(dict(name=name,n=len(indices),noise=int(np.sum(cls[indices]==7)),xyz=b64(arr),classes=b64(cls[indices].astype('u1')),bounds=[arr.min(0).tolist(),arr.max(0).tolist()],center=(center-origin).tolist() if center is not None else None))
        np.savez_compressed(C/(f['id']+'_'+str(len(views))+'.npz'),source_indices=indices,xyz_local=arr,origin=origin,classification=cls[indices],intensity=intensity[indices],return_number=ret[indices],number_of_returns=totalret[indices],synthetic=np.asarray(las.synthetic)[indices],key_point=np.asarray(las.key_point)[indices],withheld=np.asarray(las.withheld)[indices])
    bg=np.sort(rng.choice(other,min(80000,len(other)),replace=False)); make_view('타일 전체',np.sort(np.r_[bg,noise]))
    if len(noise):
        for j,index in enumerate(np.unique(np.quantile(np.arange(len(noise)),[.1,.5,.9]).astype(int))):
            anchor=xyz[noise[index]]
            # XY cylinder preserves low outliers and the terrain directly above them.
            context=np.flatnonzero(np.linalg.norm(xyz[:,:2]-anchor[:2],axis=1)<=30)
            cn=context[cls[context]==7]; cb=context[cls[context]!=7]
            cb=np.sort(rng.choice(cb,min(30000,len(cb)),replace=False))
            make_view('이상점 주변 '+str(j+1),np.sort(np.r_[cb,cn]),anchor)
    payload=dict(metadata=row,origin=origin.tolist(),views=views)
    (A/(f['id']+'.json')).write_text(json.dumps(payload,separators=(',',':')),encoding='utf-8')
    row['viewer_views']=[{k:v[k] for k in ['name','n','noise']} for v in views]
    rows.append(row)
    print(f['id'], 'points',len(xyz),'class7',len(noise),'dz',row.get('noise_dz_near_ground_q10_50_90'),flush=True)
    del las,xyz,cls
result=dict(scope='Nine metadata-selected, size-conditioned aerial calibration/demo tiles. Not a benchmark, prevalence survey, dust/sunlight label set, or a ground-LiDAR simulator calibration.',rows=rows,total_points=sum(r['points'] for r in rows),total_noise=sum(r['noise_points'] for r in rows),preserved_source_files=True,classification7_preserved=True,xyz_max_allowed_roundtrip_error_m=.002,new_training=False,heldout_opened=False)
(E/'analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('TOTAL',result['total_points'],result['total_noise'],flush=True)
