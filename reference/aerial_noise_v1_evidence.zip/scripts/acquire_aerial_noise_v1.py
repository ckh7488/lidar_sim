"""Reserve metadata-selected calibration tiles before downloading point values."""
from pathlib import Path
import concurrent.futures, hashlib, json, urllib.request, urllib.parse, xml.etree.ElementTree as ET
from datetime import datetime, timezone

R = Path('E:/NeuralMap')
E = R/'stage0/evidence/aerial_noise_v1'
T = R/'runtime/tmp/aerial_noise_v1'
E.mkdir(parents=True, exist_ok=True)
T.mkdir(parents=True, exist_ok=True)
BASE = 'https://opentopography.s3.sdsc.edu/pc-bulk'
PREFIXES = ['CA05USGSB4', 'CRB_10_Jul', 'UT18_Dennison']
NS = {'s': 'http://s3.amazonaws.com/doc/2006-03-01/'}

def list_source(prefix):
    rows, token = [], None
    while True:
        args = {'list-type': '2', 'prefix': prefix+'/', 'max-keys': 1000}
        if token:
            args['continuation-token'] = token
        url = BASE+'?'+urllib.parse.urlencode(args)
        with urllib.request.urlopen(url, timeout=45) as f:
            root = ET.fromstring(f.read())
        for n in root.findall('s:Contents', NS):
            key = n.find('s:Key', NS).text
            if key.lower().endswith(('.las', '.laz')):
                rows.append(dict(key=key, bytes=int(n.find('s:Size', NS).text), etag=n.find('s:ETag', NS).text))
        if root.find('s:IsTruncated', NS).text != 'true':
            break
        token = root.find('s:NextContinuationToken', NS).text
    return rows

manifest_path = E/'reservation.json'
if not manifest_path.exists():
    inventories = {p: list_source(p) for p in PREFIXES}
    selected = []
    for p, rows in inventories.items():
        eligible = [x for x in rows if 1_000_000 <= x['bytes'] <= 80_000_000]
        ranked = sorted(eligible, key=lambda x: hashlib.sha256(('aerial-review-20261007:'+x['key']).encode()).hexdigest())
        for i, x in enumerate(ranked[:3]):
            selected.append(dict(x, dataset=p, id=p+'_'+str(i+1), url=BASE+'/'+urllib.parse.quote(x['key']), split='calibration_demo_only'))
    manifest = dict(created=datetime.now(timezone.utc).isoformat(), policy='Three tiles per source, ranked by SHA256(seed + key), compressed/source size 1-80 MB. Selection uses only key and byte metadata, not point labels. Size-conditioned convenience sample; not representative prevalence. All other tiles unopened and not assigned to training/test. No training or performance evaluation.', seed='aerial-review-20261007:', inventory_counts={p: len(v) for p,v in inventories.items()}, inventories=inventories, selected=selected)
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
else:
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
print('RESERVED', [(x['id'], x['key'], x['bytes']) for x in manifest['selected']], flush=True)

def download(x):
    p = T/x['key']
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists() or p.stat().st_size != x['bytes']:
        # Failed partial files stay on disk; a fresh suffix avoids implicit deletion.
        if p.exists():
            p = p.with_name(p.stem+'_retry'+p.suffix)
        with p.open('wb') as dst:
            for start in range(0, x['bytes'], 4*2**20):
                end = min(x['bytes']-1, start+4*2**20-1)
                req = urllib.request.Request(x['url'], headers={'Range': f'bytes={start}-{end}'})
                with urllib.request.urlopen(req, timeout=30) as src:
                    assert src.status == 206
                    assert src.headers['Content-Range'] == f'bytes {start}-{end}/{x["bytes"]}'
                    chunk = src.read()
                    assert len(chunk) == end-start+1
                    dst.write(chunk)
    assert p.stat().st_size == x['bytes'], (p, p.stat().st_size, x['bytes'])
    sha = hashlib.sha256()
    with p.open('rb') as f:
        while chunk := f.read(2**20):
            sha.update(chunk)
    out = dict(x, path=str(p), sha256=sha.hexdigest())
    print('DOWNLOADED', x['id'], x['bytes'], flush=True)
    return out

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(download, manifest['selected']))
(E/'downloads.json').write_text(json.dumps(dict(files=results, total_bytes=sum(x['bytes'] for x in results)), indent=2), encoding='utf-8')
print('DONE', sum(x['bytes'] for x in results), flush=True)
